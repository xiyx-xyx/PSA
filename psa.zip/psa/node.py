class Node:
    id = 0
    def __init__(self, id):
        self.id = id


    def put_request(self, share):
        self.request_share = share